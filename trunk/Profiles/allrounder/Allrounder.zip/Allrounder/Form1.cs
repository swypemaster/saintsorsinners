﻿using System;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Drawing;
using Styx;
using Allrounder;
using Styx.Logic;
using Styx.Logic.Combat;
using Styx.Helpers;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using Styx.Plugins.PluginClass;
using Styx.Logic.Pathing;
using Styx.Logic.Inventory;
using Styx.Logic.Inventory.Frames.Gossip;
using Styx.Logic.Inventory.Frames.MailBox;
using System.Text.RegularExpressions;
using Styx.Logic.Profiles;

namespace Allrounder
{
    partial class AllrounderConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMilling = new System.Windows.Forms.CheckBox();
            this.btnInking = new System.Windows.Forms.CheckBox();
            this.btnProspecting = new System.Windows.Forms.CheckBox();
            this.btnEternals = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnMail = new System.Windows.Forms.CheckBox();
            this.btnDisenchant = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGuild = new System.Windows.Forms.CheckBox();
            this.btnDarkmoon = new System.Windows.Forms.CheckBox();
            this.btnGuilddeposit = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnMilling
            // 
            this.btnMilling.AutoSize = true;
            this.btnMilling.Location = new System.Drawing.Point(12, 12);
            this.btnMilling.Name = "btnMilling";
            this.btnMilling.Size = new System.Drawing.Size(77, 17);
            this.btnMilling.TabIndex = 0;
            this.btnMilling.Text = "Use Milling";
            this.btnMilling.UseVisualStyleBackColor = true;
            // 
            // btnInking
            // 
            this.btnInking.AutoSize = true;
            this.btnInking.Location = new System.Drawing.Point(12, 35);
            this.btnInking.Name = "btnInking";
            this.btnInking.Size = new System.Drawing.Size(77, 17);
            this.btnInking.TabIndex = 1;
            this.btnInking.Text = "Use Inking";
            this.btnInking.UseVisualStyleBackColor = true;
            // 
            // btnProspecting
            // 
            this.btnProspecting.AutoSize = true;
            this.btnProspecting.Location = new System.Drawing.Point(12, 59);
            this.btnProspecting.Name = "btnProspecting";
            this.btnProspecting.Size = new System.Drawing.Size(104, 17);
            this.btnProspecting.TabIndex = 2;
            this.btnProspecting.Text = "Use Prospecting";
            this.btnProspecting.UseVisualStyleBackColor = true;
            // 
            // btnEternals
            // 
            this.btnEternals.AutoSize = true;
            this.btnEternals.Location = new System.Drawing.Point(12, 83);
            this.btnEternals.Name = "btnEternals";
            this.btnEternals.Size = new System.Drawing.Size(86, 17);
            this.btnEternals.TabIndex = 5;
            this.btnEternals.Text = "Use Eternals";
            this.btnEternals.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(103, 176);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnMail
            // 
            this.btnMail.AutoSize = true;
            this.btnMail.Location = new System.Drawing.Point(123, 35);
            this.btnMail.Name = "btnMail";
            this.btnMail.Size = new System.Drawing.Size(67, 17);
            this.btnMail.TabIndex = 8;
            this.btnMail.Text = "Use Mail";
            this.btnMail.UseVisualStyleBackColor = true;
            // 
            // btnDisenchant
            // 
            this.btnDisenchant.AutoSize = true;
            this.btnDisenchant.Location = new System.Drawing.Point(123, 12);
            this.btnDisenchant.Name = "btnDisenchant";
            this.btnDisenchant.Size = new System.Drawing.Size(102, 17);
            this.btnDisenchant.TabIndex = 9;
            this.btnDisenchant.Text = "Use Disenchant";
            this.btnDisenchant.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(12, 214);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Allrounder By Alpha";
            // 
            // btnGuild
            // 
            this.btnGuild.AutoSize = true;
            this.btnGuild.Location = new System.Drawing.Point(11, 130);
            this.btnGuild.Name = "btnGuild";
            this.btnGuild.Size = new System.Drawing.Size(114, 17);
            this.btnGuild.TabIndex = 11;
            this.btnGuild.Text = "Use Guildwithdraw";
            this.btnGuild.UseVisualStyleBackColor = true;
            // 
            // btnDarkmoon
            // 
            this.btnDarkmoon.AutoSize = true;
            this.btnDarkmoon.Location = new System.Drawing.Point(123, 59);
            this.btnDarkmoon.Name = "btnDarkmoon";
            this.btnDarkmoon.Size = new System.Drawing.Size(105, 17);
            this.btnDarkmoon.TabIndex = 15;
            this.btnDarkmoon.Text = "Make Darkmoon";
            this.btnDarkmoon.UseVisualStyleBackColor = true;
            // 
            // btnGuilddeposit
            // 
            this.btnGuilddeposit.AutoSize = true;
            this.btnGuilddeposit.Location = new System.Drawing.Point(123, 130);
            this.btnGuilddeposit.Name = "btnGuilddeposit";
            this.btnGuilddeposit.Size = new System.Drawing.Size(106, 17);
            this.btnGuilddeposit.TabIndex = 18;
            this.btnGuilddeposit.Text = "Use Guilddeposit";
            this.btnGuilddeposit.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 253);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Withdraw";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(185, 253);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Deposit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 21;
            this.label2.Text = "Guild Controls";
            // 
            // AllrounderConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 287);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnGuilddeposit);
            this.Controls.Add(this.btnDarkmoon);
            this.Controls.Add(this.btnGuild);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDisenchant);
            this.Controls.Add(this.btnMail);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnEternals);
            this.Controls.Add(this.btnProspecting);
            this.Controls.Add(this.btnInking);
            this.Controls.Add(this.btnMilling);
            this.Name = "AllrounderConfig";
            this.Text = "Allrounder";
            this.Load += new System.EventHandler(this.Form1_Activated);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CheckBox btnMilling;
        private CheckBox btnInking;
        private CheckBox btnProspecting;
        private CheckBox btnEternals;
        private CheckBox btnMail;
        private CheckBox btnDisenchant;
        private Label label1;
        private CheckBox btnGuild;
        private CheckBox btnDarkmoon;
        private CheckBox btnGuilddeposit;
        private Button button1;
        private Button button2;
        private Label label2;
        private Button btnSave;
    }

    public partial class AllrounderConfig : Form
    {
        public AllrounderConfig()
        {
            InitializeComponent();
            this.Activate();
            Logging.Write(Color.Blue, "[Allrounder]:Welcome to Allrounder v3 : Time to craft some SHIT!!");
        }
        public void button1_Click(object sender, EventArgs e)
        {
            Guildwithdraw form2 = new Guildwithdraw();
            form2.ShowDialog();
            form2.Dispose();
        }
        public void button2_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
            form3.Dispose();
        }
        AllrounderSettings settings;
        public void Form1_Shown(object sender, EventArgs e)
        {
            this.Activate();
            AllrounderSettings settings = new AllrounderSettings();
            settings.LoadSettings();
            btnMilling.Checked = settings.useMilling;
            btnInking.Checked = settings.useInking;
            btnProspecting.Checked = settings.useProspecting;                     
            btnMail.Checked = settings.useMail;
            btnDisenchant.Checked = settings.useDisenchant;
            btnGuild.Checked = settings.useGuildw;
            btnGuilddeposit.Checked = settings.useGuilddeposit;
            btnDarkmoon.Checked = settings.useDarkmoon;            
        }
        public void Form1_Activated(object sender, EventArgs e)
        {
            this.Activate();
            AllrounderSettings settings = new AllrounderSettings();
            settings.LoadSettings();
            btnMilling.Checked = settings.useMilling;
            btnInking.Checked = settings.useInking;
            btnProspecting.Checked = settings.useProspecting;
            btnMail.Checked = settings.useMail;
            btnDisenchant.Checked = settings.useDisenchant;
            btnGuild.Checked = settings.useGuildw;
            btnGuilddeposit.Checked = settings.useGuilddeposit;
            btnDarkmoon.Checked = settings.useDarkmoon;
        }
        public void btnSave_Click(object sender, EventArgs e)
        {
            AllrounderSettings settings = new AllrounderSettings();
            settings.SaveSettings(btnInking.Checked,  btnMilling.Checked, btnProspecting.Checked, btnMail.Checked, btnDisenchant.Checked, btnGuild.Checked, btnDarkmoon.Checked, btnGuilddeposit.Checked);
            btnMilling.Checked = settings.useMilling;
            btnInking.Checked = settings.useInking;
            btnProspecting.Checked = settings.useProspecting;
            btnMail.Checked = settings.useMail;
            btnDisenchant.Checked = settings.useDisenchant;
            btnGuild.Checked = settings.useGuildw;
            btnGuilddeposit.Checked = settings.useGuilddeposit;
            btnDarkmoon.Checked = settings.useDarkmoon;
            Logging.Write(Color.DarkGreen, "Allrounder Settings Saved");
            Close();
        }

        #region HBStuff
        public class Allrounder : HBPlugin
        {      
            public static AllrounderConfig Form = new AllrounderConfig();
            public override string Name { get { return "Allrounder"; } }
            public override string Author { get { return "Alpha"; } }
            public override Version Version { get { return _version; } }
            private readonly Version _version = new Version(3, 0);
            public override string ButtonText { get { return "Settings"; } }
            public override bool WantButton { get { return true; } }
            public override void OnButtonPress()
            {
                Form.ShowDialog();
            }
            public WoWUnit Me = Styx.StyxWoW.Me;
            public bool useDefault = false;
            public bool useMilling { get; set; }
            public bool useInking { get; set; }
            public bool useProspecting { get; set; }
            public bool useMail { get; set; }
            public bool useDisenchant { get; set; }
            public bool useGuildw { get; set; }
            public bool useDarkmoon { get; set; }
            public bool useGuilddeposit { get; set; }
            public static readonly string PluginFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), Path.Combine("Plugins", "Allrounder"));
            #endregion
            public override void Pulse()
            {
                while (!StyxWoW.Me.Combat || !StyxWoW.Me.Dead || !StyxWoW.Me.IsInInstance || !StyxWoW.Me.IsFlying || !StyxWoW.Me.IsFalling || !StyxWoW.Me.IsCasting)
                {
                    ObjectManager.Update();
                    if (useDefault)
                    {
                        DefaultSettings();
                    }
                    
                    Guildwithdraw gw = new Guildwithdraw();
                    Form3 dw = new Form3();
                    Pulsesettingsload();
                    
                    if (useGuildw)
                    {
                        gw.PulsesettingsLoad2();
                        Guildwith.Guildwithspell();
                    }
                    if (useMail)
                    {
                        Mail.Mailspell();
                    }
                    if (useMilling)
                    {
                        Milling.milling();
                    }
                    if (useInking)
                    {
                        Inking.Inkingspell();
                    }
                    if (useProspecting)
                    {
                        Prospecting.Prospectingspell();
                    }
                    if (useDisenchant)
                    {
                        Disenchant.Disenchantspell();
                    }
                    if (useDarkmoon)
                    {
                        Darkmoon.Darkmoonspell();
                    }
                    if (useGuilddeposit)
                    {
                        dw.PulseLoadsettings3();
                        Guilddeposit.Guilddepositspell();
                    }
                }
            }   
                
            

            public void DefaultSettings()
            {
                string settingsPath = Path.Combine(PluginFolderPath, StyxWoW.Me.Name + "-Settings.xml");
                File.Delete(settingsPath);
                File.Copy(Path.Combine(PluginFolderPath, "Settings.xml"), settingsPath);
                Logging.Write(Color.Blue, "Allrounder default settings loaded, please use settings button to select your options.");
                useDefault = true;
            }

            public void Pulsesettingsload()
            {
                string settingsPath = Path.Combine(PluginFolderPath, StyxWoW.Me.Name + "-Settings.xml");
                XElement elm = XElement.Load(settingsPath);
                XElement[] options = elm.Elements("Option").ToArray();
                bool _useMilling;
                bool _useInking;
                bool _useProspecting;              
                bool _useMail;
                bool _useDisenchant;
                bool _useGuildw;              
                bool _useDarkmoon;                
                bool _useGuilddeposit;
               
                foreach (XElement opt in options)
                {
                    var value = opt.Attributes("Value").ToList();
                    var set = opt.Attributes("Set").ToList();
                    if (value[0].Value == "useMilling")
                    {
                        bool.TryParse(set[0].Value, out _useMilling);
                        useMilling = _useMilling;
                    }
                    if (value[0].Value == "useInking")
                    {
                        bool.TryParse(set[0].Value, out _useInking);
                        useInking = _useInking;
                    }
                    if (value[0].Value == "useProspecting")
                    {
                        bool.TryParse(set[0].Value, out _useProspecting);
                        useProspecting = _useProspecting;
                    }
                    if (value[0].Value == "useMail")
                    {
                        bool.TryParse(set[0].Value, out _useMail);
                        useMail = _useMail;
                    }
                    if (value[0].Value == "useDisenchant")
                    {
                        bool.TryParse(set[0].Value, out _useDisenchant);
                        useDisenchant = _useDisenchant;
                    }
                    if (value[0].Value == "useGuildw")
                    {
                        bool.TryParse(set[0].Value, out _useGuildw);
                        useGuildw = _useGuildw;
                    }
                    if (value[0].Value == "useDarkmoon")
                    {
                        bool.TryParse(set[0].Value, out _useDarkmoon);
                        useDarkmoon = _useDarkmoon;
                    }
                    if (value[0].Value == "useGuilddeposit")
                    {
                        bool.TryParse(set[0].Value, out _useGuilddeposit);
                        useGuilddeposit = _useGuilddeposit;
                    }
                }
            }
        }

        class AllrounderSettings
        #region Settings
        {
            public static readonly string PluginFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), Path.Combine("Plugins", "Allrounder"));
            public bool useMilling { get; set; }
            public bool useInking { get; set; }
            public bool useProspecting { get; set; }
            public bool useMail { get; set; }
            public bool useDisenchant { get; set; }
            public bool useGuildw { get; set; }
            public bool useDarkmoon { get; set; }
            public bool useGuilddeposit { get; set; }
            public void LoadSettings()
            {
                string settingsPath = Path.Combine(PluginFolderPath, StyxWoW.Me.Name + "-Settings.xml");
                if (File.Exists(settingsPath))
                {
                }
                else
                {
                    File.Copy(Path.Combine(PluginFolderPath, "Settings.xml"), settingsPath);
                }
                XElement elm = XElement.Load(settingsPath);
                XElement[] options = elm.Elements("Option").ToArray();
                bool _useInking;
                bool _useMilling;
                bool _useProspecting;
                bool _useMail;
                bool _useGuildw;
                bool _useDarkmoon;
                bool _useGuilddeposit;
                foreach (XElement opt in options)
                {
                    var value = opt.Attributes("Value").ToList();
                    var set = opt.Attributes("Set").ToList();
                    if (value[0].Value == "useMilling")
                    {
                        bool.TryParse(set[0].Value, out _useMilling);
                        useMilling = _useMilling;
                    }
                    if (value[0].Value == "useInking")
                    {
                        bool.TryParse(set[0].Value, out _useInking);
                        useInking = _useInking;
                    }
                    if (value[0].Value == "useProspecting")
                    {
                        bool.TryParse(set[0].Value, out _useProspecting);
                        useProspecting = _useProspecting;
                    }
                    if (value[0].Value == "useMail")
                    {
                        bool.TryParse(set[0].Value, out _useMail);
                        useMail = _useMail;
                    }
                    if (value[0].Value == "useGuildw")
                    {
                        bool.TryParse(set[0].Value, out _useGuildw);
                        useGuildw = _useGuildw;
                    }
                    if (value[0].Value == "useDarkmoon")
                    {
                        bool.TryParse(set[0].Value, out _useDarkmoon);
                        useDarkmoon = _useDarkmoon;
                    }
                    if (value[0].Value == "useGuilddeposit")
                    {
                        bool.TryParse(set[0].Value, out _useGuilddeposit);
                        useGuilddeposit = _useGuilddeposit;
                    }
                }
            }
            public void SaveSettings(bool _useInking,
                bool _useMilling,
                bool _useProspecting,
                bool _useMail,
                bool _useDisenchant,
                bool _useGuildw,
                bool _useDarkmoon,
                bool _useGuilddeposit)
                {
                string settingsPath = Path.Combine(PluginFolderPath, StyxWoW.Me.Name + "-Settings.xml");
                if (File.Exists(settingsPath))
                {
                }
                else
                {
                    File.Copy(Path.Combine(PluginFolderPath, "Settings.xml"), settingsPath);
                }
                XElement saveElm = File.Exists(settingsPath) ? XElement.Load(settingsPath) : new XElement("Settings");
                XElement[] options = saveElm.Elements("Option").ToArray();
                foreach (XElement opt in options)
                {
                    var value = opt.Attributes("Value").ToList();
                    if (value[0].Value == "useMilling")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useMilling"), new XAttribute("Set", _useMilling.ToString())));
                    }
                    if (value[0].Value == "useInking")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useInking"), new XAttribute("Set", _useInking.ToString())));
                    }
                    if (value[0].Value == "useProspecting")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useProspecting"), new XAttribute("Set", _useProspecting.ToString())));
                    }
                    if (value[0].Value == "useMail")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useMail"), new XAttribute("Set", _useMail.ToString())));
                    }
                    if (value[0].Value == "useDisenchant")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useDisenchant"), new XAttribute("Set", _useDisenchant.ToString())));
                    }
                    if (value[0].Value == "useGuildw")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useGuildw"), new XAttribute("Set", _useGuildw.ToString())));
                    }
                    if (value[0].Value == "useDarkmoon")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useDarkmoon"), new XAttribute("Set", _useDarkmoon.ToString())));
                    }
                    if (value[0].Value == "useGuilddeposit")
                    {
                        opt.ReplaceWith(new XElement("Option", new XAttribute("Value", "useGuilddeposit"), new XAttribute("Set", _useGuilddeposit.ToString())));
                    }
                    saveElm.Save(settingsPath);
        #endregion
                }
            }
        }
    }
}

       






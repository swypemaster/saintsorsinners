﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Allrounder
{
    class deposititems
    {
        public List<uint> Inklist = new List<uint>
        {
            61978, // Blackfellow Ink
	        61981, //Inferno Ink
        };

        public List<uint> GemsList = new List<uint>
        {
            52182, //Jasper
            52177, //Carnelian 
            52181, //Hessonite
            52178, //Zephyrite
            52179, //Alicite
            52180, //Nightstone
            52191,//Ocean Sapphire
            52190,//Inferno Ruby
            52195,//Amberjewel
            52194,//Demonseye
            52192,//Dream Emerald
            52193,//Ember topaz
        };

        public List<uint> Darklist = new List<uint>
        {
            61988, //Ace of Embers
            61989, //Two of Embers
            61990, //Three of Embers
            61991, //Four of Embers
            61992, //Five of embers
            61993, //Six of Embers
            61994, //Seven of Embers
            61995, //Eight of Embers

            62004, //Ace of Winds
            62005,
            62006,
            62007,
            62008,
            62009,
            62010,
            62011,//Eight of Winds

            61996,//Ace of Stones
            61997,
            61998,
            61999,
            62000,
            62001,
            62002,
            62003,//Eight of Stones

            62012,//Ace of Waves
            62013,
            62014,
            62015,
            62016,
            62017,
            62018,
            62019,//Eight of Waves
        };

        public List<uint> EternalList = new List<uint>
        {
	    52328, //Volatile Air
	    52329, //Volatile Life
 	    52327,//Volatile Earth
        52326,//Volitile Water
	    52325, //Volitile Fire
        };

        public List<uint> Disenchantlist = new List<uint>
        {

        };
    }
}